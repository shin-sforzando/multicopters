Logs files created by "SD Logs" special function will be stored in this directory.
