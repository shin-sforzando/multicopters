This directory is for Lua telemetry scripts.
Those scripts can be selected using DISPLAY screen in MODEL SETUP.
