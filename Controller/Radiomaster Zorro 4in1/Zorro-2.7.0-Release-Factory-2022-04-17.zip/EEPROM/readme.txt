EEPROM backups go in this folder.
EEPROM backups can be generated from HARDWARE screen in RADIO SETUP.
